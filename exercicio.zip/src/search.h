#ifndef SEARCH_H
#define SEARCH_H

#include "project.h"

void searchLine(void);
void searchCar(void);


#endif