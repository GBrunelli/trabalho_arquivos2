#ifndef SEARCH_H
#define SEARCH_H

#include "project.h"

// 11th task - Searching for a specific car, based on its index
void searchCar(void);

// 12th task - Searching for a specific line, based on its index
void searchLine(void);

#endif