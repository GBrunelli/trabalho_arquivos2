#ifndef PROJECT_H
#define PROJECT_H

#pragma GCC diagnostic ignored "-Wsizeof-pointer-memaccess"

// Project dependencies
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

#endif