#ifndef INSERT_H
#define INSERT_H

#include "project.h"

void insertLines(void);
void insertCars(void);


#endif