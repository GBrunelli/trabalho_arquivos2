#ifndef INSERT_H
#define INSERT_H

#include "project.h"

// 13th task - Inserting new cars on both index and data files
void insertCars(void);

// 14th task - Inserting new lines on both index and data files
void insertLines(void);

#endif