#ifndef INDEX_H
#define INDEX_H

#include "project.h"

// 9th task - Creating index for cars through B Tree
void indexCars(void);

// 10th task - Creating index for lines through B Tree
void indexLines(void);

#endif