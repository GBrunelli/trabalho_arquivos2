#ifndef INDEX_H
#define INDEX_H

#include "project.h"

void indexLines(void);
void indexCars(void);

#endif